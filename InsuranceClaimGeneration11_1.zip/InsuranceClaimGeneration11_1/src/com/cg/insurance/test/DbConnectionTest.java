package com.cg.insurance.test;

import static org.junit.Assert.*;

import java.io.IOException;
import java.sql.Connection;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;


import com.cg.insurance.dao.IInsuranceDAO;
import com.cg.insurance.dao.InsuranceDaoImpl;
import com.cg.insurance.exception.InsuranceClaimException;
import com.cg.insurance.util.DbConnection;



public class DbConnectionTest {
	static IInsuranceDAO dao=null;
	static Connection con;
	@BeforeClass
	public static void initialise() {
		dao = new InsuranceDaoImpl();
		con=null;
	}
	@Before
	public void beforeEachTest() {
		System.out.println("Starting DBConnection Test Case\n");
	}
	
	@Test
	public void testGetConnection() throws IOException, InsuranceClaimException {
		
		Connection con = DbConnection.getConnection();
		Assert.assertNotNull(con);
	}
	@After
	public void afterEachTest() {
		System.out.println("End of DBConnection Test Case\n");
	}

	@AfterClass
	public static void destroy() {
		System.out.println("\tEnd of Tests");
		dao = null;
		con = null;
	}

}
