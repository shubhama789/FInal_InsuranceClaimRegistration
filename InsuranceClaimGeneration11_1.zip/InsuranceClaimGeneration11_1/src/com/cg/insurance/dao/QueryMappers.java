package com.cg.insurance.dao;

public interface QueryMappers {
	public static final String INSERT_QWERY="INSERT INTO CLAIM(?,?,?,?,?,?,?,?)";
	public static final String GET_POLICY_NUMBER="SELECT  POLICY_NUMBER FROM claim;";
	public static final String CHECK_ACCESS="SELECT * FROM user_role WHERE user_name=?";
	public static final String INSERT_USER="INSERT INTO user_role VALUES(?,?,?)";
	public static final String SELECT_QWERY="SELECT user_name FROM user_role";
	public static final String VIEW_ALL_CLAIMS=" SELECT claim_number, claim_type, policy_number FROM claim WHERE policy_number IN (select policy_number FROM policy WHERE account_number IN (SELECT account_number FROM account WHERE user_name =?))";
	public static final String VIEW_ALL_POLICY = "SELECT * FROM POLICY WHERE ACCOUNT_NUMBER=(SELECT ACCOUNT_NUMBER FROM ACCOUNT WHERE USER_NAME=(SELECT USER_NAME FROM USER_ROLE WHERE USER_NAME=?))";
	public static final String FETCH_USER="SELECT * FROM agentuserrelation WHERE agentID=?";
	
	
	public static final String EXECUTE_QUERY = "SELECT * FROM question_table WHERE  BUSINESS_SEGMENT=?";
	public static final String INSERT_CLAIM = "INSERT INTO claim VALUES(?,?,?,?,?,?,?,?)";
	public static final String INSERT_POLICY_DETAILS = "INSERT INTO policy_details VALUES(?,?,?)";
	public static final String CHECK_CLAIM_USING_POLICY_NO = "SELECT * FROM claim WHERE policy_number=?";
	public static final String GEN_SEQ = "SELECT claimno.nextval FROM dual";
	public static final String GET_BUSINESS_SEGMENT="SELECT business_segment FROM account WHERE user_name =?";
	public static final String RETRIVE_CLAIM_DETAILS="SELECT * from claim WHERE CLAIM_NUMBER=?";
	public static final String RETRIVE_POLICY_DETAILS="SELECT question_id,answer FROM policy_details WHERE policy_number=?";
}
