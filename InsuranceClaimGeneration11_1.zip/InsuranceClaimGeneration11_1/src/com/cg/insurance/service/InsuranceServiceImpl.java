package com.cg.insurance.service;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.insurance.bean.AgentUserBean;
import com.cg.insurance.bean.ClaimBean;
import com.cg.insurance.bean.PolicyBean;
import com.cg.insurance.bean.PolicyDetailsBean;
import com.cg.insurance.bean.QuestionBean;
import com.cg.insurance.bean.UserBean;
import com.cg.insurance.dao.IInsuranceDAO;
import com.cg.insurance.dao.InsuranceDaoImpl;
import com.cg.insurance.exception.InsuranceClaimException;




public class InsuranceServiceImpl implements IInsuranceService{
	static IInsuranceDAO iInsuranceDAO=null;
	//static QuestionBean questionBean = new QuestionBean();
	//IInsuranceDAO iInsuranceDAO = null;



	private boolean isNumberValid(int claim_Number) {
		
		return claim_Number>0;
	}

	
	@Override
	public String checkAccess(UserBean userbean) throws IOException, SQLException, InsuranceClaimException {
		String rolecode;
		iInsuranceDAO = new InsuranceDaoImpl();
		rolecode=iInsuranceDAO.checkAccess(userbean);
		return rolecode;
	}

	public void validateUserDetails(UserBean userbean) throws InsuranceClaimException {
		List<String> validationErrors = new ArrayList<String>();
		
		if(!(isValidName(userbean.getUsername()))) {
			validationErrors.add("\n User Name Should Be Minimum 5 and maximum 20 characters and start with character \n");
		}
		if(!(isValidPassword(userbean.getPassword()))) {
			validationErrors.add("\n Password should contain atleast 1 Upper, 1 lower, 1 digit, 1 special characters and length must be in 8 to 12   \n");
		}
		
		if(!validationErrors.isEmpty()) {
			throw new InsuranceClaimException(validationErrors+"");
		}
		
	}

	private boolean isValidPassword(String password) {
		Pattern namePattern=Pattern.compile("^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[`~#?!@$(_/+:;|)%^&*-]).{8,12}$");
		Matcher nameMatcher=namePattern.matcher(password);
		return nameMatcher.matches();
	}

	private boolean isValidName(String username) {
		Pattern namePattern=Pattern.compile("^[A-Za-z][A-Za-z0-9]{4,19}$");
		Matcher nameMatcher=namePattern.matcher(username);
		return nameMatcher.matches();
	}

	@Override
	public void addUser(UserBean userbean) throws InsuranceClaimException, IOException {
		iInsuranceDAO = new InsuranceDaoImpl();
		iInsuranceDAO.addUser(userbean);
		
	}

	

	@Override
	public List<ClaimBean> viewAllClaims(String name) throws InsuranceClaimException, IOException, SQLException {
		List<ClaimBean> claimList = new ArrayList<ClaimBean>();
		iInsuranceDAO = new InsuranceDaoImpl();
		claimList = iInsuranceDAO.viewAllClaims(name);
		return claimList;
	}

	@Override
	public List<PolicyBean> viewAllPolicies(String name) throws IOException, InsuranceClaimException, SQLException {
		List<PolicyBean> policyList = new ArrayList<PolicyBean>();
		iInsuranceDAO = new InsuranceDaoImpl();
		policyList = iInsuranceDAO.viewAllPolicy(name);
		return policyList;
	}

	@Override
	public List<AgentUserBean> fetchUsers(String name) throws IOException, InsuranceClaimException, SQLException {
		List<AgentUserBean> agentUserList = new ArrayList<AgentUserBean>();
		iInsuranceDAO = new InsuranceDaoImpl();
		agentUserList = iInsuranceDAO.fetchUsers(name);
		return agentUserList;
	}

	

	@Override
	public List<QuestionBean> getQuestions(String businessSegment)
			throws ClassNotFoundException, IOException, SQLException, InsuranceClaimException {
		iInsuranceDAO = new InsuranceDaoImpl();
		List<QuestionBean> list = new ArrayList<>();
		list = iInsuranceDAO.getQuestions(businessSegment);

		return list;
	}

	@Override
	public boolean validateDetails(ClaimBean claimBean) throws InsuranceClaimException {
		List<String> list = new ArrayList<>();

		boolean result = true;

		
		if (!isReasonValid(claimBean.getClaimReason())) {
			list.add("claim reason should be valid");
		}
		if (!isAccidentLocationValid(claimBean.getAccidentLocationStreet())) {
			list.add("Location should be valid without numerics");
		}
		if (!isAccidentCityValid(claimBean.getAccidentCity())) {
			list.add("city should be valid without numerics");
		}
		if (!isAccidentStateValid(claimBean.getAccidentState())) {
			list.add("state should be valid without numerics");
		}
		if (!isAccidentZipValid(claimBean.getAccidentZip())) {
			list.add("Enter valid ZIP Code");
		}
//		if (!isPolicyNumberValid(claimBean.getPolicyNumber())) {
//		list.add("policy number should be greater than 0");
//		 }
		if (!list.isEmpty()) {

			System.out.println("Errors" + list);
			result = false;
		}

		return result;

	}

//	private boolean isPolicyNumberValid(long l) {
//
//		return l > 0;
//	}

	private boolean isAccidentZipValid(String accidentZip) {
		String RegEx = "^[1-9][0-9]{5}$";
		Pattern pattern = Pattern.compile(RegEx);
		Matcher matcher = pattern.matcher(accidentZip);
		return matcher.matches();
		
	}

	private boolean isAccidentStateValid(String accidentState) {
		String RegEx = "^[A-Z][A-Za-z]{3,20}$";
		Pattern pattern = Pattern.compile(RegEx);
		Matcher matcher = pattern.matcher(accidentState);
		return matcher.matches();
	}

	private boolean isAccidentCityValid(String accidentCity) {
		String RegEx = "^[A-Z][A-Za-z]{3,20}$";
		Pattern pattern = Pattern.compile(RegEx);
		Matcher matcher = pattern.matcher(accidentCity);
		return matcher.matches();
	}

	private boolean isAccidentLocationValid(String accidentLocation) {
		String RegEx = "^[A-Z][A-Za-z]{3,20}$";
		Pattern pattern = Pattern.compile(RegEx);
		Matcher matcher = pattern.matcher(accidentLocation);
		return matcher.matches();
	}

	private boolean isReasonValid(String claimReason) {
		String RegEx = "^[A-Z][A-Za-z]{3,20}$";
		Pattern pattern = Pattern.compile(RegEx);
		Matcher matcher = pattern.matcher(claimReason);
		return matcher.matches();
	}


	@Override
	public String createClaim(ClaimBean claimBean,List<PolicyDetailsBean> policyDetailsList) throws ClassNotFoundException, Exception {
		iInsuranceDAO = new InsuranceDaoImpl();
		return iInsuranceDAO.createClaim(claimBean,policyDetailsList);
	}

	@Override
	public String getBusinessSegment(String name) throws ClassNotFoundException, IOException, SQLException, InsuranceClaimException {
		// TODO Auto-generated method stub
		iInsuranceDAO=new InsuranceDaoImpl();
		String segment=iInsuranceDAO.getBusinessSegment(name);
		return segment;
		
	}


	@Override
	public List generateReport(String ClaimNo)
			throws ClassNotFoundException, IOException, SQLException, InsuranceClaimException {
		
			
			return iInsuranceDAO.generateReport(ClaimNo);
		
	}


}
