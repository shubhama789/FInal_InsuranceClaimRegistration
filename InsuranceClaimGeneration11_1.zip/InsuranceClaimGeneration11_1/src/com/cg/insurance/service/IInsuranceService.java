package com.cg.insurance.service;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import com.cg.insurance.bean.AgentUserBean;
import com.cg.insurance.bean.ClaimBean;
import com.cg.insurance.bean.PolicyBean;
import com.cg.insurance.bean.PolicyDetailsBean;
import com.cg.insurance.bean.QuestionBean;
import com.cg.insurance.bean.UserBean;
import com.cg.insurance.exception.InsuranceClaimException;




public interface IInsuranceService {

	

	String checkAccess(UserBean userbean) throws IOException, SQLException, InsuranceClaimException;

	void addUser(UserBean userbean) throws InsuranceClaimException, IOException;

	List<ClaimBean> viewAllClaims(String name) throws InsuranceClaimException, IOException, SQLException;

	List<PolicyBean> viewAllPolicies(String name) throws IOException, InsuranceClaimException, SQLException;

	List<AgentUserBean> fetchUsers(String name) throws IOException, InsuranceClaimException, SQLException;

	boolean validateDetails(ClaimBean claimBean) throws InsuranceClaimException;

	public String createClaim(ClaimBean claimNumber,List<PolicyDetailsBean> policyDetailsList) throws SQLException, InsuranceClaimException, ClassNotFoundException, Exception;
	
	public List<QuestionBean> getQuestions(String businessSegment) throws ClassNotFoundException, IOException, SQLException, InsuranceClaimException;
	
	public String getBusinessSegment(String name) throws ClassNotFoundException, IOException, SQLException, InsuranceClaimException;

	List generateReport(String claim) throws ClassNotFoundException, IOException, SQLException ,InsuranceClaimException;

	


}
